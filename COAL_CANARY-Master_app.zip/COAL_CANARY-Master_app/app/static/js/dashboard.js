/* globals Chart:false, feather:false */


/*function MainDashboardDisplay() {
    let content = document.querySelector('#tweetFeaturette').innerHTML =
    <div class="row featurette">
        <div class="col-md-7">
            <h2 class="featurette-heading">First featurette heading. <span class="text-muted">It’ll blow your mind.</span></h2>
            <p class="lead">Some great placeholder content for the first featurette here. Imagine some exciting prose here.</p>
        </div>
        <div class="col-md-5">
            <svg class="bd-placeholder-img bd-placeholder-img-lg featurette-image img-fluid mx-auto" width="500" height="500" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 500x500" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#eee"></rect><text x="50%" y="50%" fill="#aaa" dy=".3em">500x500</text></svg>
        </div>
    </div>
}*/



/*getNFTs = async () => {
  console.log('get nfts clicked');

  // Hide/display on click
  var x = document.getElementById("tableOfNFTs");
  if (x.style.display === "block") {
      x.style.display = "none";
  } else {
      x.style.display = "block";
  }

  let nfts = await Moralis.Web3API.account.getNFTs({ chain: 'rinkeby' }); //'rinkeby', modify to mainnet
  console.log(nfts);
  let tableOfNFTs = document.querySelector('#tableOfNFTs');

  if (nfts.result.length > 0) {
      nfts.result.forEach(n => {
          let metadata = JSON.parse(n.metadata);
          let content = `
              <div class="card col-md-3">
                  <img src="${fixURL(metadata.image_url)}" class="card-img-top" height=300>
                      <div class="card-body">
                          <h5 class="card-title">${metadata.name}</h5>
                          <p class="card-text">${metadata.description}</p>
                          <a href="#" class="btn btn-primary">Go somewhere</a>
                      </div>
              </div>
          `
          tableOfNFTs.innerHTML += content;

      })
  }

}

// Fix url for NFTs displays
fixURL = (url) => {
  if (url.startsWith("ipfs")){
      return "https://ipfs.moralis.io:2053/ipfs/" + url.split("ipfs://").slice(-1)
  }
  else{
      return url + "?format=json"
  }
}*/