/*
Coal Canary Project - ETH Online 2021 - @StevnSwedn
Built on Moralis protocole, including elements from NFTPort and Polygon
Submission date: oct-10-2021

*/

//settings.AutoRedirectMode = RedirectMode.Off;

// Connect to Moralis server
Moralis.initialize("orvtlDDN2gcKSrYluWiI70yuRaYF0gtwQdCJqbKW");
Moralis.serverURL = "https://v3xniz9rj3mf.grandmoralis.com:2053/server";

//const Moralis = require('moralis');
//// ES6 Minimized
//import Moralis from 'moralis/dist/moralis.min.js';


// If the user is not connected but arrives on the dashboard, hide all and redirect to the sign-in page
let homepage = "http://127.0.0.1:5500/signin_index.html"
if (Moralis.User.current() == null && window.location.href != homepage) {
    document.querySelector('body').style.display = 'none';
    window.location.href = "signin_index.html";
}

// Login to the dashboard
login = async () => {
    await Moralis.authenticate().then(async function (user) {
        console.log('logged in');
        console.log(Moralis.User.current());
        user.set("name", document.getElementById('user-username').value);
        user.set("email", document.getElementById('user-email').value);
        await user.save();
        window.location.href = "dashboard.html";
        
    })
}

// Logout from the dashboard to the sign-in page
logout = async () => {
    await Moralis.User.logOut();
    window.location.href = "signin_index.html";
}


// >>Display the dashboard content<<
getMainDashboard = async () => {
    console.log('main dashboard clicked');
    
    // Hide/display on click
   var x = document.getElementById("mainDashboard");
    if (x.style.display === "block") {
         x.style.display = "none";
         MainDashboardDisplay();
    } else {
         x.style.display = "block";
    }
}
function MainDashboardDisplay(){
    let table =`
    <div class="col-12">
            <label for="email" class="form-label">Tweet URL</label>
            <input type="email" class="form-control" id="TweetURL" placeholder="https://twitter.com/Interior/status/463440424141459456">
          </div>
          `
}

/*            <div class="invalid-feedback">
              Please enter a valid twitter URL to display the image.
            </div>
            */
           
/*
function MainDashboardDisplay() {
    let content = document.querySelector('#tweetFeaturette').innerHTML =`
    <div class="row featurette">
        <div class="col-md-7">
            <h2 class="featurette-heading">First featurette heading. <span class="text-muted">It’ll blow your mind.</span></h2>
            <p class="lead">Some great placeholder content for the first featurette here. Imagine some exciting prose here.</p>
        </div>
        <div class="col-md-5">
            <svg class="bd-placeholder-img bd-placeholder-img-lg featurette-image img-fluid mx-auto" width="500" height="500" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 500x500" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#eee"></rect><text x="50%" y="50%" fill="#aaa" dy=".3em">500x500</text></svg>
        </div>
    </div>`
}*/


// >>Get the transaction list from the user<<
getTransactions = async () => {
    console.log('get transactions clicked');

    // Hide/display on click
    var x = document.getElementById("tableOfTransactions");
    if (x.style.display === "block") {
        x.style.display = "none";
    } else {
        x.style.display = "block";
    }

    //<td >${t.from_address == Moralis.User.current().get('ethAddress') ? 'Outgoing' : 'Incoming'}</td>
    const options = { chain: "Eth", address: "0x0a1D0c720d139c50F6D31c377D08Ef17d1000748" };   //"rinkeby"     //Should get the address from the user, on main chaine
    const transactions = await Moralis.Web3API.account.getTransactions(options);
    console.log(transactions);

    // Display the table only if the user has at least 1 transaction
    if (transactions.total > 0) {

        let table = `
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Transaction on Ethereum Blockchain</th>
                        <th scope="col">Block Number</th>
                        <th scope="col">Age</th>
                        <th scope="col">Type</th>
                        <th scope="col">Fee</th>
                        <th scope="col">Value</th>
                    </tr>
                </thead>
                <tbody id="theTransactions">
                </tbody>
            </table>
            `
        document.querySelector('#tableOfTransactions').innerHTML = table;

        // Filling the table
        transactions.result.forEach(t => {
            let content = `
                <tr>
                    <td ><a style="color: black" href='https://rinkeby.etherscan.io/tx/${t.hash}' target="_blank" rel="noopener noreferrer"> ${t.hash}</a></td>
                    <td ><a style="color: black" href='https://rinkeby.etherscan.io/block/${t.block_number}' target="_blank" rel="noopener noreferrer"> ${t.block_number}</a></td>
                    <td >${millisecondsToTime(Date.parse(new Date()) - Date.parse(t.block_timestamp))}</td>
                    <td >${t.from_address == Moralis.User.current().get('ethAddress') ? 'Outgoing' : 'Incoming'}</td>
                    <td >${((t.gas * t.gas_price) / 1e18).toFixed(5)} ETH</td>
                    <td >${(t.value / 1e18).toFixed(5)} ETH</td>
                </tr>
                `
            theTransactions.innerHTML += content;

        })
    }

}

// >>Get the balance list from the user<<
getBalances = async () => {
    console.log('get balanced clicked')

    // Hide/display on click
    var x = document.getElementById("userBalances");
    if (x.style.display === "block") {
        x.style.display = "none";
    } else {
        x.style.display = "block";
    }

    const options = {};
    const ethBalance = await Moralis.Web3API.account.getNativeBalance();
    //const ropstenBalance = await Moralis.Web3API.account.getNativeBalance({ chain: "ropsten" });
    //const rinkebyBalance = await Moralis.Web3API.account.getNativeBalance({ chain: "rinkeby" });
    console.log((ethBalance.balance / 1e18).toFixed(5) + "ETH");
    //console.log((ropstenBalance.balance / 1e18).toFixed(5) + "ETH");
    //console.log((rinkebyBalance.balance / 1e18).toFixed(5) + "ETH");

    let content = document.querySelector('#userBalances').innerHTML = `
    <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Token</th>
                        <th scope="col">Balance</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th>Ether</th>
                        <td>${(ethBalance.balance / 1e18).toFixed(5)} ETH</td>
                    </tr>

                </tbody>
            </table>
    `
}

/*<tr>
<th>Ropsten</th>
<td>${(ropstenBalance.balance / 1e18).toFixed(5)} ETH</td>
</tr>
<tr>
<th>Rinkeby</th>
<td>${(rinkebyBalance.balance / 1e18).toFixed(5)} ETH</td>
</tr>*/

// >>Get the NFTs list from the user<<
getNFTs = async () => {
    console.log('get nfts clicked');

    // Hide/display on click
    var x = document.getElementById("tableOfNFTs");
    if (x.style.display === "block") {
        x.style.display = "none";
    } else {
        x.style.display = "block";
    }

    let nfts = await Moralis.Web3API.account.getNFTs({ chain: 'Eth' }); //'rinkeby', modify to mainnet
    console.log(nfts);
    let tableOfNFTs = document.querySelector('#tableOfNFTs');

    if (nfts.result.length > 0) {
        nfts.result.forEach(n => {
            console.log(n.metadata);
            console.log(JSON.parse(n.metadata));
            let metadata = JSON.parse(n.metadata);
            let content = `
                <div class="card col-md-2">
                    <img src="${fixURL(metadata.image)}" class="card-img-top"  >
                        <div class="card-body">
                            <h5 class="card-title">${metadata.name}</h5>
                            <p class="card-text">${metadata.description}</p>
                            <a href="#" class="btn btn-primary">Go somewhere</a>
                        </div>
                </div>
            `
            tableOfNFTs.innerHTML += content;

        })
    }

}

// Fix url for NFTs displays
fixURL = (url) => {
    if (url.startsWith("ipfs")){
        return "https://ipfs.moralis.io:2053/ipfs/" + url.split("ipfs://").slice(-1)
    }
    else{
        return url + "?format=json"
    }
}


// Time function 
millisecondsToTime = (ms) => {
    let minutes = Math.floor(ms / (1000 * 60));
    let hours = Math.floor(ms / (1000 * 60 * 60));
    let days = Math.floor(ms / (1000 * 60 * 60 * 24));
    if (days < 1) {
        if (hours < 1) {
            if (minutes < 1) {
                return `less than a minute ago`
            } else return `${minutes} minute(s) ago`
        } else return `${hours} hour(s) ago`
    } else return `${days} days(s) ago`
}


// Calling function when clicking on the dashboard menu
if (document.querySelector('#btn-login') != null) {
    document.querySelector('#btn-login').onclick = login;
}
if (document.querySelector('#btn-logout') != null) {
    document.querySelector('#btn-logout').onclick = logout;
}

if (document.querySelector('#main-Dashboard-link ') != null) {
    document.querySelector('#main-Dashboard-link').onclick = getMainDashboard;
}

if (document.querySelector('#get-transaction-link ') != null) {
    document.querySelector('#get-transaction-link').onclick = getTransactions;
}

if (document.querySelector('#get-balances-link ') != null) {
    document.querySelector('#get-balances-link').onclick = getBalances;
}

if (document.querySelector('#get-nfts-link ') != null) {
    document.querySelector('#get-nfts-link').onclick = getNFTs;
} 
